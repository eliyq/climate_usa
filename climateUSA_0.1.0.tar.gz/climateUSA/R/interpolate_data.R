#' Interpolate Climate Data for Grid Locations
#'
#' Interpolates climate data values for grid locations based on provided station climate data.
#'
#' Given a data set of station data, this function interpolates weather data values for
#' specified grid locations. It can interpolate based on longitude, latitude, and
#' additional covariates.
#'
#' @param grid a data frame containing longitude and latitude coordinates
#' of grid locations (the result of usa_grid),
#' @param data a data frame containing climate station data filtered
#' to the months and years wanted, assuming all the covariates (e.g. longitude, latitude, elevation)
#' are in the data frame
#' @param value the value to be interpolated
#' @param covariates an optional data frame containing all covariates
#' (e.g. longitude, latitude, elevation) to be included in the model
#' @param stat the summary statistic function to be applied (default: mean)
#' @return a data frame containing longitude, latitude, and interpolated predicted values
#' for the grid locations
#' @examples
#' # interpolate average temperature for grid locations
#' interpolated_data <- interpolate_data(grid = usa_grid(), data = climate_data)
#'
#'# interpolate average temperature for March 2024
#' stations <- unique(climate_data$WBANNO)
#' march_2024_data <- do.call(rbind, lapply(stations, function(station_id) {
#' time_series(station_id = station_id, data = climate_data, start_date = "2024-03-01",
#' end_date = "2024-03-31")}))
#' interpolate_data(grid = usa_grid(resolution = 0.5), data = march_2024_data,
#' covariates = usa_grid(resolution = 0.5), stat = mean)
#'
#' # interpolate maximum temperature data for grid locations with a resolution of 0.5
#' interpolated_data <- interpolate_data(grid = usa_grid(resolution = 0.5),
#' data = climate_data, value = "T_DAILY_MAX")
#' @importFrom rlang .data
#' @export
interpolate_data <- function(grid, data, value = "T_DAILY_AVG", covariates = NULL, stat = mean) {
  if(!(is.null(covariates))) {
    colnames(covariates) <- toupper(colnames(covariates))
  }

  if (is.null(covariates) || !("LONGITUDE" %in% colnames(covariates)) || !("LATITUDE" %in% colnames(covariates))) {
    grouping_vars <- c("LONGITUDE", "LATITUDE")
  } else {
    grouping_vars <- names(covariates)
  }

  station_table <- data |>
    dplyr::group_by(dplyr::across(dplyr::all_of(grouping_vars))) |>
    dplyr::summarize(VALUE = stat(.data[[value]], na.rm = TRUE), .groups = "drop")

  station_table <- station_table[is.finite(station_table$VALUE), ]

  if (!is.null(covariates)) {
    formula <- stats::as.formula(paste("~", paste(colnames(covariates), collapse = " + ")))
    fit <- GpGp::fit_model(y = station_table$VALUE,
                           locs = as.matrix(station_table[, c("LONGITUDE", "LATITUDE")]),
                           X = stats::model.matrix(formula, data = station_table),
                           covfun_name = "matern_sphere",
                           silent = TRUE)
    X_pred <- matrix(1, nrow = nrow(grid), ncol = 1)
    X_pred <- cbind(X_pred, as.matrix(covariates))
    pred <- GpGp::predictions(fit = fit,
                              X_pred = X_pred,
                              locs_pred = as.matrix(grid))
  } else {
    fit <- GpGp::fit_model(y = station_table$VALUE,
                           locs = as.matrix(station_table[, c("LONGITUDE", "LATITUDE")]),
                           covfun_name = "matern_sphere",
                           silent = TRUE)
    pred <- GpGp::predictions(fit = fit,
                              X_pred = matrix(1, nrow = nrow(grid), ncol = 1),
                              locs_pred = as.matrix(grid))
  }

  results <- cbind(grid, pred)
  colnames(results) <- c("LONGITUDE", "LATITUDE", "PREDICTIONS")
  return(results)

}
