#' Create Grid Points Inside the Contiguous United States
#'
#' Generates a grid of points inside the contiguous United States at a specified resolution.
#'
#' This function generates a grid of points covering the geographical extent of
#' the contiguous United States at a specified resolution.
#' The resolution determines the size of grid points.
#'
#' @param resolution the resolution of the grid, indicating the size of
#' grid points (default: 1)
#' @return a data frame containing longitude and latitude coordinates of points
#' inside the contiguous United States
#' @examples
#' # generate grid points with default resolution
#' grid_points <- usa_grid()
#'
#' # generate grid points with a resolution of 0.5
#' grid_points <- usa_grid(resolution = 0.5)
#' @export
usa_grid <- function(resolution = 1) {
  usa_map <- ggplot2::map_data("state")
  usa_polygons <- split(usa_map, f = usa_map$group)

  bbox <- range(usa_map$long, na.rm = TRUE)
  bbox_lat <- range(usa_map$lat, na.rm = TRUE)
  grid <- expand.grid(
    x = seq(from = bbox[1], to = bbox[2], by = resolution),
    y = seq(from = bbox_lat[1], to = bbox_lat[2], by = resolution)
  )

  inside <- logical(nrow(grid))
  for(polygon in usa_polygons) {
    inside <- inside | sp::point.in.polygon(point.x = grid$x, point.y = grid$y,
                                            pol.x = polygon$long, pol.y = polygon$lat) > 0
  }

  points_inside_usa <- grid[inside, ]
  colnames(points_inside_usa) <- c("LONGITUDE", "LATITUDE")

  return(points_inside_usa)
}
