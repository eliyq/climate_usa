test_that("plot interpolated grid looks ok", {
  interpolate <- interpolate_data(grid = usa_grid(resolution = 0.5),
                           data = climate_data,
                           covariates = usa_grid(resolution = 0.5),
                           stat = mean)
  info <- plot_interpolated_grid(interpolate)
  expect_equal(info, info)
})

test_that("plot interpolated grid looks ok", {
  interpolate <- interpolate_data(grid = usa_grid(resolution = 0.5),
                           data = climate_data,
                           covariates = usa_grid(resolution = 0.5),
                           stat = mean)
  info <- plot_interpolated_grid(interpolate)
  expect_equal(typeof(info), "list")
})

