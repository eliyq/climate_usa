#' Plot Interpolated Graph
#'
#' Plots the interpolated graph of climate data values.
#'
#' Given interpolated climate data values for grid locations, this function
#' plots the grids.
#'
#' @param interpolation a data frame containing longitude, latitude,
#' and interpolated prediction values (the result of interpolate_data)
#' @return a plot showing the interpolated graph of interpolated climate data values
#' @examples
#' # plot interpolated grid for climate data
#' stations <- unique(climate_data$WBANNO)
#' march_2024_data <- do.call(rbind, lapply(stations, function(station_id) {
#' time_series(station_id = station_id, data = climate_data,
#' start_date = "2024-03-01", end_date = "2024-03-31")}))
#' interpolated_data <- interpolate_data(usa_grid(resolution = 0.5), march_2024_data,
#' covariates = usa_grid(resolution = 0.5), stat = mean)
#' plot_interpolated_grid(interpolated_data)
#' @export
plot_interpolated_grid <- function(interpolation) {
  colnames(interpolation) <- toupper(colnames(interpolation))

  grid_location <- data.frame(LONGITUDE = interpolation$LONGITUDE,
                              LATITUDE = interpolation$LATITUDE)
  orders <- order(grid_location$LONGITUDE, grid_location$LATITUDE)
  grid_location <- grid_location[orders,]
  grid_longitude <- unique(grid_location$LONGITUDE)
  grid_latitude <- unique(grid_location$LATITUDE)

  full_grid <- expand.grid(grid_longitude, grid_latitude)
  names(full_grid) <- c("LONGITUDE", "LATITUDE")

  full_grid$PREDICTIONS <- NA
  merged_data <- merge(full_grid, interpolation, by = c("LONGITUDE", "LATITUDE"),
                       all.x = TRUE)
  full_grid$PREDICTIONS <- merged_data[[4]]

  matrix_values <- matrix(full_grid$PREDICTIONS,
                          nrow = length(unique(grid_longitude)),
                          ncol = length(unique(grid_latitude)),
                          byrow = TRUE)

  avg_latitude <- mean(grid_latitude)
  aspect_ratio <- 1 / cos(avg_latitude * pi / 180)

  fields::image.plot(x = sort(unique(grid_longitude)),
                     y = sort(unique(grid_latitude)),
                     z = matrix_values,
                     asp = aspect_ratio,
                     main = "Interpolated Plot",
                     xlab = "Longitude",
                     ylab = "Latitude")

  maps::map("usa", add = TRUE, col = "black")

}
