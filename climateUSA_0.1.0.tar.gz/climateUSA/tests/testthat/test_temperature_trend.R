test_that("temperature trend looks ok", {
  info <- temperature_trend(station_id = 53878, data = climate_data)
  expect_equal(typeof(info), "double")
})

test_that("temperature trend looks ok", {
  info <- temperature_trend(station_id = 53878, data = climate_data, summary = TRUE)
  expect_equal(typeof(info), "list")
})
