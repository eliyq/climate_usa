#' Estimate Yearly Cycle
#'
#' Estimate the yearly cycle for the expected temperature of a specific station.
#'
#' Given a station id and a data set containing temperature (e.g. minimum, maximum, average, etc.),
#' this function calculates the yearly cycle of expected temperature.
#' As an option, it can plot the predicted yearly cycle and the actual temperature.
#'
#' @param station_id the id of the station
#' @param data a data frame containing the climate data,
#' assuming the station id column is called WBANNO and the date column is called LST_DATE
#' @param response the response variable for which to calculate the yearly cycle
#' (default: "T_DAILY_AVG")
#' @param plot logical; if TRUE, a plot of the predicted yearly cycle and
#' the actual temperature is generated (default: FALSE)
#' @return a data frame containing the predicted temperature for each day of the year
#' @examples
#' # calculate the yearly cycle of daily averages temperatures
#' yearly_avg_temp_cycle <- yearly_cycle(station_id = 53878, data = climate_data)
#'
#' # calculate the yearly cycle of daily minimum temperatures and plot the results
#' yearly_min_temp_cycle <- yearly_cycle(station_id = 53878, data = climate_data,
#' response = "T_DAILY_MIN", plot = TRUE)
#' @importFrom rlang .data
#' @export
yearly_cycle <- function(station_id, data, response = "T_DAILY_AVG", plot = FALSE) {
  station_data <- dplyr::filter(data, .data$WBANNO == station_id)
  station_data$DAY_OF_YEAR <- as.numeric(format(station_data$LST_DATE, "%j"))

  x <- 2 * pi * station_data$DAY_OF_YEAR / 365.25
  fit <- stats::lm(station_data[[response]] ~ sin(x) + cos(x) + sin(2*x) + cos(2*x))

  days <- 1:365
  new_x <- 2 * pi * days / 365.25
  predictions <- stats::predict(fit, newdata = data.frame(DAY_OF_YEAR = days, x = new_x))

  results <- data.frame(
    DAY_OF_YEAR = days,
    PREDICTED_TEMP = predictions)

  if (plot == TRUE) {
    daily_averages <- stats::aggregate(station_data[[response]] ~ DAY_OF_YEAR, data = station_data, mean)
    plot(days, predictions, type = "l", lwd = 2, col = "blue",
         main = "Yearly Temperature Cycle",
         xlab = "Day of Year",
         ylab = "Temperature (Celsius)")
    graphics::lines((1:366/366*366.25), daily_averages[, 2], type = "l", col ="black")
  }

  return(results)
}
