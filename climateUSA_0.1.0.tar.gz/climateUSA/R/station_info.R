#' Station Information Data
#'
#' This dataset contains information for each station.
#'
#' @format A data frame with observations on the following 5 variables.
#' \describe{
#'   \item{STATION_IDENTIFIER}{\code{character}, The station WBAN number (5 characters).}
#'   \item{STATION_NAME}{\code{character}, Station name.}
#'   \item{STATE}{\code{character}, State name abbreviation. (2 characters).}
#'   \item{LONGITUDE}{\code{numeric}, Station longitude, using WGS-84 (7 characters).}
#'   \item{LATITUDE}{\code{numeric}, Station latitude, using WGS-84 (7 characters).}
#' }
"station_info"
