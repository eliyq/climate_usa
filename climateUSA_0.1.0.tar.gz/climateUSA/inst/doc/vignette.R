## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(climateUSA)

library(class)
library(elevatr)
library(dplyr)
library(maps)
library(sf)

data("climate_data")

## -----------------------------------------------------------------------------
stations <- unique(climate_data$WBANNO)
march_2024_data <- do.call(rbind, lapply(stations, function(station_id) {
  time_series(station_id = station_id, data = climate_data, 
              start_date = "2024-03-01", end_date = "2024-03-31", 
              variables = c("T_DAILY_AVG", "LATITUDE", "LONGITUDE"))
}))

avg_march_2024_temp <- aggregate(T_DAILY_AVG ~ WBANNO + LATITUDE + LONGITUDE, 
                                 data = march_2024_data, FUN = mean)

min_temp <- min(avg_march_2024_temp$T_DAILY_AVG)
max_temp <- max(avg_march_2024_temp$T_DAILY_AVG)

num_colors <- 100
colors <- colorRampPalette(c("blue", "red"))(num_colors)
color_breaks <- seq(min_temp, max_temp, length.out = num_colors + 1)

map("state")
map.axes(xlab = "Longitude", ylab = "Latitude")

points(avg_march_2024_temp$LONGITUDE, avg_march_2024_temp$LATITUDE,
       col = colors[cut(avg_march_2024_temp$T_DAILY_AVG, color_breaks, include.lowest = TRUE)],
       pch = 20, cex = 0.8)

legend("bottomright", 
       legend = round(seq(min_temp, max_temp, length.out = 5), 1), 
       fill = colors[seq(1, num_colors, length.out = 5)], 
       title = "Avg Temp (°C)",
       cex = 0.7)

title(main = "Average Temperature at Each Station for March 2024", 
      xlab = "Longtitude", ylab = "Latitude")

## -----------------------------------------------------------------------------
march_2024_data_1 <- do.call(rbind, lapply(stations, function(station_id) {
  time_series(station_id = station_id, data = climate_data, 
              start_date = "2024-03-01", end_date = "2024-03-31", 
              variables = c("T_DAILY_AVG", "LONGITUDE","LATITUDE"))
}))

location <- march_2024_data_1[,c("LONGITUDE","LATITUDE")]
names(location)[names(location) == "LONGITUDE"] <- "x"
names(location)[names(location) == "LATITUDE"] <- "y"

station_listing_with_elevation <- get_elev_point(locations = location, 
                                 prj = "+proj=longlat +datum=WGS84", 
                                 src = "aws", 
                                 z = 5)

station_listing_with_elevation$ELEVATION_FEET <- station_listing_with_elevation$elevation * 3.28084

station_listing_with_elevation <- st_as_sf(station_listing_with_elevation)
station_listing_with_elevation<- cbind(station_listing_with_elevation,
                                       st_coordinates(station_listing_with_elevation))
names(station_listing_with_elevation)[names(station_listing_with_elevation) == "X"] <- "LONGITUDE"
names(station_listing_with_elevation)[names(station_listing_with_elevation) == "Y"] <- "LATITUDE"
coords <- st_coordinates(station_listing_with_elevation)
station_listing_with_elevation <- data.frame(LONGITUDE = coords[, "X"],
                                        LATITUDE = coords[, "Y"],
                                        ELEVATION = station_listing_with_elevation$ELEVATION_FEET)

merged_data <- unique(merge(march_2024_data_1, station_listing_with_elevation, 
                         by = c("LONGITUDE", "LATITUDE")))

usa_grid_points <- usa_grid(resolution = 0.05)
names(usa_grid_points)[names(usa_grid_points) == "LONGITUDE"] <- "x"
names(usa_grid_points)[names(usa_grid_points) == "LATITUDE"] <- "y"

elevation_data <- get_elev_point(locations = usa_grid_points, 
                                 prj = "+proj=longlat +datum=WGS84", 
                                 src = "aws", 
                                 z = 5)

elevation_data$ELEVATION_FEET <- elevation_data$elevation * 3.28084

elevation_data <- st_as_sf(elevation_data)
elevation_data <- cbind(elevation_data, st_coordinates(elevation_data))
names(elevation_data)[names(elevation_data) == "X"] <- "LONGITUDE"
names(elevation_data)[names(elevation_data) == "Y"] <- "LATITUDE"
coords <- st_coordinates(elevation_data)
covariates_with_elevation <- data.frame(LONGITUDE = coords[, "X"],
                                        LATITUDE = coords[, "Y"],
                                        ELEVATION = elevation_data$ELEVATION_FEET)

interpolated_data_with_elevation <- interpolate_data(grid = usa_grid_points, 
                                                     data = merged_data, 
                                                     value = "T_DAILY_AVG", 
                                                     covariates = covariates_with_elevation,
                                                     stat = mean)

plot_interpolated_grid(interpolated_data_with_elevation)

## -----------------------------------------------------------------------------
# Plot for warmest and coldest day of the year for each station

# Calculate the warmest and coldest day for each station
warmest_days <- sapply(stations, function(station_id) {
  cycle <- yearly_cycle(station_id = station_id, data = climate_data, response = "T_DAILY_AVG")
  warmest_day <- cycle$DAY_OF_YEAR[which.max(cycle$PREDICTED_TEMP)]
  return(warmest_day)
})

coldest_days <- sapply(stations, function(station_id) {
  cycle <- yearly_cycle(station_id = station_id, data = climate_data, response = "T_DAILY_AVG")
  coldest_day <- cycle$DAY_OF_YEAR[which.min(cycle$PREDICTED_TEMP)]
  return(coldest_day)
})

# Create data frames for plotting
warmest_days_data <- data.frame(
  WBANNO = stations,
  LONGITUDE = climate_data$LONGITUDE[match(stations, climate_data$WBANNO)],
  LATITUDE = climate_data$LATITUDE[match(stations, climate_data$WBANNO)],
  WARMEST_DAY = warmest_days
)

coldest_days_data <- data.frame(
  WBANNO = stations,
  LONGITUDE = climate_data$LONGITUDE[match(stations, climate_data$WBANNO)],
  LATITUDE = climate_data$LATITUDE[match(stations, climate_data$WBANNO)],
  COLDEST_DAY = coldest_days
)

# Determine the range of days for the warmest days
min_day_warmest <- min(warmest_days_data$WARMEST_DAY)
max_day_warmest <- max(warmest_days_data$WARMEST_DAY)

custom_palette_warmest <- colorRampPalette(
  c("yellow", "gold", "orange", "red", "darkred"))(max_day_warmest - min_day_warmest + 1)

map("state")
map.axes(xlab = "Longitude", ylab = "Latitude")

points(warmest_days_data$LONGITUDE, warmest_days_data$LATITUDE, 
       col = custom_palette_warmest[warmest_days_data$WARMEST_DAY - min_day_warmest + 1], 
       pch = 16, cex = 0.8)

legend_labels_warmest <- seq(min_day_warmest, max_day_warmest, length.out = 5)
legend("bottomright", 
       legend = paste("Day", round(legend_labels_warmest)), 
       fill = custom_palette_warmest[round(legend_labels_warmest - min_day_warmest + 1)], 
       title = "Warmest Day",
       cex = 0.65)
title(main = "Warmest Day Of The Year For Each Station", xlab = "Longtitude", ylab = "Latitude")

# Determine the range of days for the coldest days
min_day_coldest <- min(coldest_days_data$COLDEST_DAY)
max_day_coldest <- max(coldest_days_data$COLDEST_DAY)

# Define a new sequence that cycles from 320 to 365 and then from 1 to 20
coldest_day_sequence <- c(355:365, 1:55)

custom_palette_coldest <- colorRampPalette(
  c("cyan", "deepskyblue", "blue", "lightgreen", "green"))(length(coldest_day_sequence))

# Map the coldest day values to the corresponding colors
col_indices <- match(coldest_days_data$COLDEST_DAY, coldest_day_sequence)

map("state")
map.axes(xlab = "Longitude", ylab = "Latitude")

points(coldest_days_data$LONGITUDE, coldest_days_data$LATITUDE, 
       col = custom_palette_coldest[col_indices], 
       pch = 16, cex = 0.8)

legend_labels_coldest <- c(355, 365, 5, 15, 25, 35, 45, 55)
legend("bottomright", 
       legend = paste("Day", legend_labels_coldest), 
       fill = custom_palette_coldest[match(legend_labels_coldest, coldest_day_sequence)], 
       title = "Coldest Day",
       cex = 0.65)
title(main = "Coldest Day Of The Year For Each Station", xlab = "Longtitude", ylab = "Latitude")

## -----------------------------------------------------------------------------
# Interpolated Maps
usa_grid_points <- usa_grid(resolution = 0.05)

# Interpolated map for the warmest days
interpolated_warmest_days <- interpolate_data(
  grid = usa_grid_points, 
  data = warmest_days_data, 
  value = "WARMEST_DAY"
)
plot_interpolated_grid(interpolated_warmest_days)

# Interpolated map for the coldest days
interpolated_coldest_days <- interpolate_data(
  grid = usa_grid_points, 
  data = coldest_days_data, 
  value = "COLDEST_DAY"
)
plot_interpolated_grid(interpolated_coldest_days)

## -----------------------------------------------------------------------------
# Specify the chosen stations
chosen_stations <- c(3047, 4136, 92821, 63856, 54933, 53878, 94644, 4994, 94088, 53927)

# Create a data frame with the station IDs and names
stations_info <- data.frame(
  WBANNO = chosen_stations,
  NAME = c("TX_Monahans_6_ENE", "WA_Spokane_17_SSW", "FL_Titusville_7_E", "GA_Brunswick_23_S", 
           "SD_Aberdeen_35_WNW", "NC_Asheville_13_S", "ME_Old_Town_2_W", "MN_Goodridge_12_NNW", 
           "WY_Sundance_8_NNW", "OK_Stillwater_5_WNW")
)

yearly_cycles <- lapply(chosen_stations, function(station_id) {
  yearly_cycle(station_id = station_id, data = climate_data, response = "T_DAILY_AVG")
})

par(mar = c(5, 4, 4, 10) + 0.1)

plot(NULL, 
     xlim = c(1, 365), 
     ylim = range(sapply(yearly_cycles, function(cycle) cycle$PREDICTED_TEMP)), 
     xlab = "Day of Year", ylab = "Average Temperature (°C)", 
     main = "Yearly Cycles for 10 Stations")

colors <- rainbow(10)
labels <- stations_info$NAME

for (i in 1:10) {
  lines(yearly_cycles[[i]]$DAY_OF_YEAR, yearly_cycles[[i]]$PREDICTED_TEMP, col = colors[i], lwd = 2)
}

par(xpd = TRUE)
legend("topright", 
       inset = c(-0.56, 0.25), 
       legend = labels, 
       col = colors, 
       lwd = 2, 
       title = "Stations", 
       bty = "n", 
       cex = 0.8)
par(xpd = FALSE)

## -----------------------------------------------------------------------------
# Plot of trend over the years for each station, in units of degrees Celsius per year
trends_data <- sapply(unique(climate_data$WBANNO), function(station_id) {
  result <- temperature_trend(station_id, climate_data, summary = TRUE)
  return(c(result$TREND, result$SUMMARY$coefficients[2, 2], result$SUMMARY$coefficients[2, 4]))
})

trends_df <- data.frame(
  WBANNO = unique(climate_data$WBANNO),
  LONGITUDE = climate_data$LONGITUDE[match(stations, climate_data$WBANNO)],
  LATITUDE = climate_data$LATITUDE[match(stations, climate_data$WBANNO)],
  TREND = trends_data[1, ],
  STANDARD_ERROR = trends_data[2, ],
  P_VALUE = trends_data[3, ]
)

# Set SIGNIFICANT column to the P_VALUE if P_VALUE < 0.01, otherwise NA
trends_df$SIGNIFICANT <- ifelse(trends_df$P_VALUE < 0.01, trends_df$P_VALUE, NA)
trends_df$SE_SMALL <- ifelse(trends_df$STANDARD_ERROR 
                             < summary(trends_df$STANDARD_ERROR)["3rd Qu."], 
                             trends_df$STANDARD_ERROR, NA)

significant_trends <- trends_df[!is.na(trends_df$SIGNIFICANT), ]
non_significant_trends <- trends_df[is.na(trends_df$SIGNIFICANT), ]
color_gradient_significant <- colorRampPalette(
  c("lightblue", "blue"))(nrow(significant_trends))
color_gradient_non_significant <- colorRampPalette(
  c("lightpink", "red"))(nrow(non_significant_trends))

map("state")
map.axes(xlab = "Longitude", ylab = "Latitude")

# Plot significant trends (circles)
points(significant_trends$LONGITUDE, significant_trends$LATITUDE,
       col = color_gradient_significant[rank(significant_trends$TREND, ties.method = "first")],
       pch = 19, cex = 0.8)

# Plot non-significant trends (triangles)
points(non_significant_trends$LONGITUDE, non_significant_trends$LATITUDE,
       col = color_gradient_non_significant[rank(non_significant_trends$TREND, ties.method = "first")],
       pch = 17, cex = 0.8)

legend("bottomright", 
       legend = c("Significant - Highest", "Significant - Lowest", 
                  "Not Significant - Highest", "Not Significant - Lowest"),
       col = c("blue", "lightblue", "red", "lightpink"),
       pch = c(19, 19, 17, 17),
       cex = 0.5)

title(main = "Significance of Temperature Trends at Each Station", 
      xlab = "Longtitude", ylab = "Latitude")

## -----------------------------------------------------------------------------
# Interpolated Maps

usa_grid_points <- usa_grid(resolution = 0.05)

se_small_trends <- significant_trends[!is.na(significant_trends$SE_SMALL), ]

interpolated_trend <- interpolate_data(
  grid = usa_grid_points, 
  data = se_small_trends[, c("WBANNO", "LONGITUDE", "LATITUDE", "TREND")], 
  value = "TREND"
)
plot_interpolated_grid(interpolated_trend)

## -----------------------------------------------------------------------------
average_trend <- mean(se_small_trends$TREND)
print(paste("Average Temperature Trend for Contiguous USA:", average_trend, "°C/year"))

source_trend <- (1.592469771*(5/9)*(1/100))
comparison <- abs(average_trend - source_trend)
print(paste("Average Temperature Trend from Source:", source_trend, "°C/year"))
print(paste("Difference from Source:", comparison, "°C/year"))

