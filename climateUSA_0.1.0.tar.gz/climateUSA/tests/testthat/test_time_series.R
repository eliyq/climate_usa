test_that("time series looks ok", {
  info <- time_series(station_id = 53878,
                      data = climate_data,
                      start_date = "2001-06-26", end_date = "2001-07-03",
                      variables = c("T_DAILY_MAX", "T_DAILY_MIN"))
  expect_equal(names(info),
               c("WBANNO", "LST_DATE", "T_DAILY_MAX", "T_DAILY_MIN"))
})
