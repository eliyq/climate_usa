#' Estimate Temperature Trend
#'
#' Estimate the trend of temperatures over time for a specific station,
#' in units of degrees Celsius per year.
#'
#' Given a station id and a data frame containing daily weather data,
#' this function calculates the temperature trend over time using a linear regression model.
#' The trend is computed as the slope of the linear regression line fitted to
#' the input response variable.
#'
#' @param station_id the id of the station
#' @param data a data frame containing the climate data,
#' assuming the station id column is called WBANNO and the date column is called LST_DATE
#' @param response the response variable for which to calculate the temperature trend
#' (default: "T_DAILY_AVG")
#' @param summary logical; if TRUE, returns a summary of the linear regression model (default: FALSE)
#' @return if summary = FALSE, returns the temperature trend as a numeric value;
#' if summary = TRUE, returns a list containing the temperature trend and summary table
#' of the linear regression model
#' @examples
#' # calculate average temperature trend for station with id 53878
#' trend_result <- temperature_trend(station_id = 53878, data = climate_data)
#'
#' # calculate average temperature trend and return the summary statistics
#' trend_summary <- temperature_trend(station_id = 53878, data = climate_data,
#' summary = TRUE)
#'
#' # calculate minimum temperature trend
#' trend_summary <- temperature_trend(station_id = 53878, data = climate_data,
#' response = "T_DAILY_MIN")
#' @importFrom rlang .data
#' @export
temperature_trend <- function(station_id, data, response = "T_DAILY_AVG", summary = FALSE) {
  if (!is.null(station_id)) {
    station_data <- dplyr::filter(data, .data$WBANNO == station_id)
  } else {
    station_data <- data
  }

  station_data$DAYS_SINCE_2000 <- as.numeric(difftime(as.Date(station_data$LST_DATE),
                                                      as.Date("2000-01-01"),
                                                      units = "days"))

  x <- 2 * pi * (station_data$DAYS_SINCE_2000%%365.25)/365.25
  y <- station_data$DAYS_SINCE_2000/365.25
  trend_model <- stats::lm(station_data[[response]] ~ y + sin(x) + cos(x) + sin(2*x) + cos(2*x),
                           data = station_data)

  trend_slope <- summary(trend_model)$coefficients[2]

  if (summary == TRUE) {
    summary <- summary(trend_model)
    return(list(TREND = trend_slope, SUMMARY = summary))
  } else {
    return(trend_slope)
  }
}
