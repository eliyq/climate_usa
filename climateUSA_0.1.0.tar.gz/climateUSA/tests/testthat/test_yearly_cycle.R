test_that("yearly cycle looks ok", {
  info <- yearly_cycle(station_id = 53878, data = climate_data)
  expect_equal(typeof(info), "list")
})
