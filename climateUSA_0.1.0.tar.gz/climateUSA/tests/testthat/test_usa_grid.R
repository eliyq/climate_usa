test_that("usa grid looks ok", {
  info <- usa_grid(resolution = 0.5)
  expect_equal(typeof(info), "list")
})
