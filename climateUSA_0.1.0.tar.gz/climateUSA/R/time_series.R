#' Extract Time Series Data
#'
#' Extract time series data for a specific station by station id from a data set.
#'
#' Given a station id, this function filters the provided data set to extract
#' the time series data for that station. The start and end dates, and
#' specific variables to extract can be specified as an option.
#'
#' @param station_id the id of the station
#' @param data a data frame containing the climate data,
#' assuming the station id column is called WBANNO and the date column is called LST_DATE
#' @param start_date an optional start date (in YYYY-MM-DD format) to filter the data
#' @param end_date an optional end date (in YYYY-MM-DD format) to filter the data
#' @param variables an optional character vector of variable names to extract from the data frame
#' @return a data frame containing the filtered time series data for the specified station,
#' start and end dates, and variables
#' @examples
#' # extract time series data for station with id 53878
#' time_series <- time_series(station_id = 53878, data = climate_data)
#'
#' # extract time series data, specifying a start and end dates
#' time_series <- time_series(station_id = 53878, data = climate_data,
#' start_date = "2001-06-26", end_date = "2001-07-03")
#'
#' # extract specific variables (daily maximum and minimum)
#' time_series <- time_series(station_id = 53878, data = climate_data,
#' variables = c("T_DAILY_MAX", "T_DAILY_MIN"))
#' @importFrom rlang .data
#' @export
time_series <- function(station_id, data, start_date = NULL, end_date = NULL, variables = NULL) {
  station_time_series <- dplyr::filter(data, .data$WBANNO == station_id)
  if (!is.null(start_date)) {
    station_time_series <- station_time_series[station_time_series$LST_DATE >= as.Date(start_date), ]
  }
  if (!is.null(end_date)) {
    station_time_series <- station_time_series[station_time_series$LST_DATE <= as.Date(end_date), ]
  }
  if (!is.null(variables)) {
    station_time_series <- station_time_series[, c("WBANNO", "LST_DATE", variables)]
  }
  return(station_time_series)
}
