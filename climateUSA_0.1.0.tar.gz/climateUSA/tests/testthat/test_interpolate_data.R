test_that("interpolate data looks ok", {
  info <- interpolate_data(grid = usa_grid(resolution = 0.5),
                           data = climate_data,
                           covariates = usa_grid(resolution = 0.5),
                           stat = mean)
  expect_equal(typeof(info), "list")
})
