#' Climate Data Observations
#'
#' This data set contains climate observations collected from various stations.
#'
#' @format A data frame with observations on the following 13 variables.
#' \describe{
#'   \item{WBANNO}{\code{character}, The station WBAN number (5 characters).}
#'   \item{STATE}{\code{character}, State name abbreviation. (2 characters).}
#'   \item{STATION_NAME}{\code{character}, Station name.}
#'   \item{LST_DATE}{\code{Date}, The Local Standard Time (LST) date of the observation (8 characters).}
#'   \item{CRX_VN}{\code{character}, The version number of the station datalogger program (6 characters).}
#'   \item{LONGITUDE}{\code{numeric}, Station longitude, using WGS-84 (7 characters).}
#'   \item{LATITUDE}{\code{numeric}, Station latitude, using WGS-84 (7 characters).}
#'   \item{T_DAILY_MAX}{\code{numeric}, Maximum air temperature, in degrees Celsius (7 characters).}
#'   \item{T_DAILY_MIN}{\code{numeric}, Minimum air temperature, in degrees Celsius (7 characters).}
#'   \item{T_DAILY_MEAN}{\code{numeric}, Mean air temperature, in degrees Celsius (7 characters).}
#'   \item{T_DAILY_AVG}{\code{numeric}, Average air temperature, in degrees Celsius (7 characters).}
#'   \item{P_DAILY_CALC}{\code{numeric}, Total amount of precipitation, in mm (7 characters).}
#'   \item{SOLARAD_DAILY}{\code{numeric}, Total solar energy, in MJ/m^2, calculated from hourly global solar radiation rates (8 characters).}
#' }
"climate_data"
